// const BASE_URL = 'http://localhost:3000/'
// const ALLOW_REQUESTS = 'http://localhost:5173'
// const CONECTION_OBJECT = {
//   host: 'localhost',
//   user: 'root',
//   password: '',
//   database: 'items',
// }

const BASE_URL = 'https://driveclone.es/'
const ALLOW_REQUESTS = 'https://driveclone.es/'
const CONECTION_OBJECT = {
  host: 'localhost',
  user: 's281656_itemsUser',
  password: 'itemsUser.password',
  database: 's281656_items',
}

module.exports = {
  BASE_URL,
  ALLOW_REQUESTS,
  CONECTION_OBJECT,
}
